# Geolocational-Data-for-suitable-reasturant-using-Python
Find the best accommodation for students in Bangalore (or any other city of your choice) by classifying accommodation for incoming students on the basis of their preferences on amenities, budget and proximity to the location.
